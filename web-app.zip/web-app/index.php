<?php
$correct_username = 'myusername';
$correct_password = 'mypassword';

if(isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username === $correct_username && $password === $correct_password) {
        echo 'Flag: VAAS{removed_flag_from_prod}';
    } else {
        echo 'Incorrect username or password';
    }
}
?>

<form method="post" action="">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>
    <br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>
    <br>
    <input type="submit" name="submit" value="Submit">
</form>
